package be.tradelec.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import be.tradelec.web.util.BodyExtractRequestWrapper;
import be.tradelec.web.util.LogUtilities;

@Controller
public class HttpInfoController {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@RequestMapping(value = "/test1")//, method = RequestMethod.PUT
	public void test1(@RequestBody String body, Writer writer) throws IOException {
		writer.write(body);
	}
	
	@RequestMapping(value = "/test2")
	public void test2(HttpServletRequest request, HttpServletResponse response, @RequestBody String body) {
		log.debug("body: {}", body);
	}

	@RequestMapping(value = "/test")
	public void test(HttpServletRequest request, HttpServletResponse response) {
		try {
			BodyExtractRequestWrapper requestWrapper = new BodyExtractRequestWrapper(request);
			request = requestWrapper;
		} catch (IOException iOException) {
			log.warn("request wrapping failed: {}", iOException.toString());
			iOException.printStackTrace();
		}

		if (LogUtilities.logHttpServletRequest(request))
			log.debug("logged request in get handler to db: {}", request);

		PrintWriter out = null;
		try {
			out = response.getWriter();

			if (request.getHeader("accept").contains("application/json")) {
				log.debug("accept content type application/json");
				// response.setContentType("application/json");
				response.setContentType("text/html");
				out.write(LogUtilities.getRequestDataAsJsonString(request));
			} else if (request.getHeader("accept").contains("text/html")) {
				log.debug("accept content type text/html");
				response.setContentType("text/html");
				out.write(LogUtilities.getRequestDataAsHtmlString(request));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		out.close();
	}
}
