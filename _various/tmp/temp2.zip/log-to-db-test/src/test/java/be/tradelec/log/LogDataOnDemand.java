package be.tradelec.log;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Log.class)
public class LogDataOnDemand {
}
