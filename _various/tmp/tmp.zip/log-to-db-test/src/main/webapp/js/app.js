require.config({
	urlArgs : "bust=" + (new Date()).getTime()
});
require(
		[ "libs/order!jquery", "libs/order!libs/ps-log4js-console-ext", "libs/order!libs/ember-0.9.8.1", "libs/order!libs/ember-0.9.8.1", ],
		function($) {
			console.error("test error from app.js");
		});
