package com.prefabsoft.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prefabsoft.web.util.BodyExtractRequestWrapper;
import com.prefabsoft.web.util.LogUtilities;

@Controller
public class HttpInfoController {

	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@RequestMapping(value = "/in**/**")
	public ResponseEntity<String> in(HttpServletRequest request, HttpEntity<String> requestEntity){
		
		String prettyRequestDataAsJsonString = LogUtilities.logRequestDataAsJsonString(request, requestEntity);
		
		/*
		ResponseEntity<String> responseEntity;
		
		if (request.getHeader("accept").contains("application/json")) {
			responseEntity = 
		}
		*/
		
		return new ResponseEntity<String>(prettyRequestDataAsJsonString,HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/test0")
	public void test0(HttpServletRequest request, HttpServletResponse response,
			@RequestBody String body) {

		log.debug("body: {}", body);

		if (LogUtilities.logHttpServletRequest(request))
			log.debug("logged request in get handler to db: {}", request);

		PrintWriter out = null;
		try {
			out = response.getWriter();

			if (request.getHeader("accept").contains("application/json")) {
				log.debug("accept content type application/json");
				// response.setContentType("application/json");
				response.setContentType("text/html");
				out.write(LogUtilities.getRequestDataAsJsonString(request));
			} else if (request.getHeader("accept").contains("text/html")) {
				log.debug("accept content type text/html");
				response.setContentType("text/html");
				out.write(LogUtilities.getRequestDataAsHtmlString(request));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		out.close();
	}

	@RequestMapping(value = "/test1")
	// , method = RequestMethod.PUT
	public void test1(@RequestBody String body, Writer writer)
			throws IOException {
		writer.write(body);
	}

	@RequestMapping(value = "/test2")
	public void test2(HttpServletRequest request, HttpServletResponse response,
			@RequestBody String body) {
		log.debug("body: {}", body);
	}

	@RequestMapping(value = "/tst**")
	public void test(HttpServletRequest request, HttpServletResponse response) {
		try {
			BodyExtractRequestWrapper requestWrapper = new BodyExtractRequestWrapper(
					request);
			request = requestWrapper;
		} catch (IOException iOException) {
			log.warn("request wrapping failed: {}", iOException.toString());
			iOException.printStackTrace();
		}

		if (LogUtilities.logHttpServletRequest(request))
			log.debug("logged request in get handler to db: {}", request);

		PrintWriter out = null;
		try {
			out = response.getWriter();

			if (request.getHeader("accept").contains("application/json")) {
				log.debug("accept content type application/json");
				// response.setContentType("application/json");
				response.setContentType("text/html");
				out.write(LogUtilities.getRequestDataAsJsonString(request));
			} else if (request.getHeader("accept").contains("text/html")) {
				log.debug("accept content type text/html");
				response.setContentType("text/html");
				out.write(LogUtilities.getRequestDataAsHtmlString(request));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		out.close();
	}
}
