package com.prefabsoft.web;

import com.prefabsoft.log.PrefabLog;
import org.springframework.roo.addon.web.mvc.controller.scaffold.RooWebScaffold;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/prefablogs")
@Controller
@RooWebScaffold(path = "prefablogs", formBackingObject = PrefabLog.class)
public class PrefabLogController {
}
